You will need Adobe Acrobat Reader to view the downloadable database instruction file. You can download this software from Adobe's web site. To get the software at no cost, copy and paste the link below into the browser address bar. It will take you to the Adobe Acrobat Reader download site.

http://www.adobe.com/products/acrobat/readstep2.html

